<?php

class Upload_model extends CI_model
{
	function insert($formArray){
		
		$this->db->insert('images',$formArray);
		// $this->db->last_query();
		// die();

	}

	function all()
	{
		return $images =$this->db->get('images')->result_array();
		
	}
}
?>

