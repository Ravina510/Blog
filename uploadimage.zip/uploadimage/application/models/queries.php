<?php
class Queries extends CI_model
{
	function insertImage($data)
	{
		return $this->db->insert('tbl_image',$data);
	}

	function getImages()
	{
		$query=$this->db->get('tbl_image');
		if ($query->num_rows() > 0) {
			
			return $query->result();
		}
	}
}
?>