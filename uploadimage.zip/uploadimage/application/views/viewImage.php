<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <!-- jQuery library -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <!-- Popper JS -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <!-- Latest compiled JavaScript -->
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

	<style>
 img {
 	 height:300px;
	 width:300px; 
	 margin:40px;
	 float: left;
}

	i {
	color: red;
	text-align: right;

}

</style>
</head>
<body>
	<!-- <?php print_r($images);
	  //die();
	  ?> -->
	<div class="container p-3 my-3 bg-primary text-white">
		<div class="row">
			<div class="col-md-12">
		
		<h3 >Galary</h3 >
		</div>
		</div>
	</div>
		<div class="container">
			<div class="row" >
		<!-- <div class="table-responsive" >
			<div class="col-14">
            <table class="table" >
            	
             <tr>
                <?php if(count($images)):?>
                	
				<?php foreach ($images as $img): ?>
			<div class="">
				<img src=<?php echo $img->avatar ; ?> />
			</div>

				<?php endforeach;?>
				<?php else:	?>
				<p>No image found</p>
				<?php endif;?>
             </tr>
           
            
            </table>
            </div> -->

            
            
                <?php if(count($images)):?>
				<?php foreach ($images as $img): ?>
			<div class="col-md-4">

				<img src="<?php echo $img->avatar; ?>"  />
				<?php echo "image".$img->id; ?>  
				<!-- <?php echo $img->file_name ?> -->
				
			</div>

				<?php endforeach;?>
				<?php else:	?>
				<p>No image found</p>
				<?php endif;?>
             
            </div>
          </div>
  
</body>
</html>