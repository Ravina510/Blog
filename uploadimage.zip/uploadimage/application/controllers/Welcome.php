<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('imageUpload');
	}

	public function uploadPic()
	{
		$config= [
			'upload_path' => './uploads',
			'allowed_types' => 'gif|png|jpg|jpeg'
		];
		$this->load->library('upload',$config);
		$this->form_validation->set_error_delimiters();
		if ($this->upload->do_upload()) {
			$data=$this->input->post();
			$info=$this->upload->data();
			$image_path=base_url("uploads/".$info['raw_name'].$info['file_ext']);
			$data['avatar']=$image_path;
			unset($data['submit']);
			
                     // $data = $this->upload->data();  
                     // $config['image_library'] = 'gd2';  
                     // $config['source_image'] = './upload/'.$data["file_name"];  
                     // $config['create_thumb'] = FALSE;  
                     // $config['maintain_ratio'] = FALSE;  
                     // $config['quality'] = '60%';  
                     // $config['width'] = 200;  
                     // $config['height'] = 200;  
                     // $config['new_image'] = './upload/'.$data["file_name"];  
                     // $this->load->library('image_lib', $config);  
                     // $this->image_lib->resize();  
                     // $this->load->model('main_model');  
                     // $image_data = array(  
                     //      'name'          =>     $data["file_name"]  
                     //      );  
			$this->load->model('Queries');
			if($this->Queries->insertImage($data))
			{
				//echo "image successfully uploaded";
				$images=$this->Queries->getImages();
				// print_r($images);
				// exit();
				$this->load->view('viewImage',['images'=>$images]);
			}
			else{
				echo "unsuccessfull";
			}
		}
		else
		{
			$this->index();
		}
	}

	public function viewImages()
	{
		$this->load->model('Queries');
		$images=$this->Queries->getImages();
		// print_r($images);
		// exit();
		$this->load->view('viewImage',['images'=>$images]);
		//redirect('imageUpload');
	}
}
