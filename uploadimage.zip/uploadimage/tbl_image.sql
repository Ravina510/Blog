-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2020 at 07:05 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ravina3`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_image`
--

CREATE TABLE `tbl_image` (
  `id` int(11) NOT NULL,
  `avatar` varchar(100) NOT NULL,
  `file_name` varchar(150) NOT NULL,
  `file_type` varchar(150) NOT NULL,
  `file_path` varchar(150) NOT NULL,
  `full_path` varchar(150) NOT NULL,
  `raw_name` varchar(150) NOT NULL,
  `orig_name` varchar(150) NOT NULL,
  `client_name` varchar(150) NOT NULL,
  `file_ext` varchar(150) NOT NULL,
  `file_size` int(150) NOT NULL,
  `is_image` varchar(150) NOT NULL,
  `image_width` int(150) NOT NULL,
  `image_height` int(150) NOT NULL,
  `image_type` varchar(150) NOT NULL,
  `image_size_str` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_image`
--

INSERT INTO `tbl_image` (`id`, `avatar`, `file_name`, `file_type`, `file_path`, `full_path`, `raw_name`, `orig_name`, `client_name`, `file_ext`, `file_size`, `is_image`, `image_width`, `image_height`, `image_type`, `image_size_str`) VALUES
(1, 'http://[::1]/CodeIgniterUpload/uploads/WIN_20200826_11_52_05_Pro_(2)1.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(2, 'http://[::1]/CodeIgniterUpload/uploads/17.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(3, 'http://[::1]/CodeIgniterUpload/uploads/3.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(4, 'http://[::1]/CodeIgniterUpload/uploads/11.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(5, 'http://[::1]/CodeIgniterUpload/uploads/111.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(6, 'http://[::1]/CodeIgniterUpload/uploads/pancard.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(7, 'http://[::1]/CodeIgniterUpload/uploads/ravinachavhan.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(8, 'http://[::1]/CodeIgniterUpload/uploads/WIN_20200826_11_52_13_Pro_(2).jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(9, 'http://[::1]/CodeIgniterUpload/uploads/WIN_20200826_11_52_13_Pro_(2)1.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(10, 'http://[::1]/CodeIgniterUpload/uploads/WIN_20200826_11_52_05_Pro_(2).jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(11, 'http://[::1]/CodeIgniterUpload/uploads/WIN_20200826_11_52_05_Pro_(2)1.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(12, 'http://[::1]/CodeIgniterUpload/uploads/WIN_20200826_11_52_05_Pro_(2)2.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(13, 'http://[::1]/CodeIgniterUpload/uploads/WIN_20200826_11_52_05_Pro_(2)3.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(14, 'http://[::1]/CodeIgniterUpload/uploads/WIN_20200826_11_52_05_Pro_(2)4.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(15, '', 'WIN_20200826_11_52_04_Pro16.jpg', 'image/jpeg', 'C:/xampp/htdocs/CodeIgniterUpload/uploads/', 'C:/xampp/htdocs/CodeIgniterUpload/uploads/WIN_20200826_11_52_04_Pro16.jpg', 'WIN_20200826_11_52_04_Pro16', 'WIN_20200826_11_52_04_Pro.jpg', 'WIN_20200826_11_52_04_Pro.jpg', '.jpg', 150, '1', 1024, 768, 'jpeg', 'width=\"1024\" height=\"768\"'),
(16, '', 'wp11.jpg', 'image/jpeg', 'C:/xampp/htdocs/CodeIgniterUpload/uploads/', 'C:/xampp/htdocs/CodeIgniterUpload/uploads/wp11.jpg', 'wp11', 'wp1.jpg', 'wp1.jpg', '.jpg', 50, '1', 720, 1280, 'jpeg', 'width=\"720\" height=\"1280\"'),
(17, 'http://[::1]/CodeIgniterUpload/uploads/wp12.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(18, 'http://[::1]/CodeIgniterUpload/uploads/ravinachavhan1.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(19, 'http://[::1]/CodeIgniterUpload/uploads/htmlhtml5.png', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(20, 'http://[::1]/CodeIgniterUpload/uploads/Annotation_2020-08-08_135427.png', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(21, 'http://[::1]/CodeIgniterUpload/uploads/Annotation_2020-08-07_095932.png', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(22, 'http://[::1]/CodeIgniterUpload/uploads/Annotation_2020-08-09_125156.png', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', ''),
(23, 'http://[::1]/CodeIgniterUpload/uploads/screenshot.jpg', '', '', '', '', '', '', '', '', 0, '', 0, 0, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_image`
--
ALTER TABLE `tbl_image`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_image`
--
ALTER TABLE `tbl_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
